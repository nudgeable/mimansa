---
name: mimansa-stay-talk
description: Run Mimansa's Stay Talk toolkit with an HR team. Short talks that help people tell you what is wrong. While they still care enough to stay. Use when: twice a year for each person in your team; after a big change, like a new boss, a reorg or the increment letters; when a good person seems quiet or tired.
---

# Stay Talk

A Mimansa toolkit, turned into a skill. Mimansa Research & Advisory, mimansa.work. Free to use and share.

Toolkit page: https://mimansa.work/toolkits/stay-talk-kit.html

## What it helps with

**Ask before they leave.** Exit talks come too late. By then, people are polite and already gone. A stay talk is a short, kind chat with someone who is still here. You ask what keeps them, and what might make them go. Then you fix one thing. Small fixes, done fast, build trust.

**Who it is for:** People managers run the talks. HRBPs set the rhythm and track the actions.

**Use it when:**
- Twice a year for each person in your team.
- After a big change, like a new boss, a reorg or the increment letters.
- When a good person seems quiet or tired.

## How to work with the person
1. Ask who they are (HR head, HRBP, manager), the company's size and sector, and which step they are on. Start there.
2. Take the steps below in order. For each step, say who does it, what to do, and check the "done when" line before moving on.
3. Use the files in `tools/`. Spreadsheets: fill them with the person's own numbers and keep the formulas. One-page PDFs: use them as the script or checklist for the conversation, and draft their content in the same shape.
4. Write the way people talk: short sentences, plain words, no jargon. Indian context by default: April to March year, Indian labour law and practice.
5. Never make up a number. Ask for it, or mark it as a guess and say who should confirm it. For anything legal or statutory, ask them to check with payroll or an employment lawyer.
6. End each session with what was decided, who owns the next step, and by when.

## The steps

### Step 1: Book 30 minutes (Day 1)
Who: The manager does this.
- Book a quiet slot, away from the review cycle.
- Say it is a stay talk, not a review.
- Add it to the Stay Interview Tracker.

Done when: A date is set and the person knows why.
Tools: Stay Interview Tracker

### Step 2: Ask the five questions (30 min)
Who: The manager asks. The person does most of the talking.
- Use the Five Stay Questions card.
- Listen more than you speak. Do not defend.
- Write down their words, not your view of them.

Done when: You have heard what keeps them and what might make them go.
Tools: Five Stay Questions

### Step 3: Agree one action (5 min)
Who: The manager and the person agree it together.
- Pick one thing you can change within a month.
- Name who owns it and by when.
- Log it in the Stay Interview Tracker the same day.

Done when: One action has an owner and a date.
Tools: Stay Interview Tracker

### Step 4: Follow up in two weeks (Day 14)
Who: The manager does this. The HRBP checks the tracker each month.
- Tell the person what you did, even if it is not done yet.
- Ask if it helped.
- Update the status, and set the next talk six months out.

Done when: The person has heard back, and the next talk is booked.
Tools: Stay Interview Tracker

## The tools
- **Five Stay Questions** (`tools/Five Stay Questions.pdf`): The questions to ask, in order, with space for their words and one agreed action.
- **Stay Interview Tracker** (`tools/Stay Interview Tracker.xlsx`): Who is due a talk, who is overdue, actions and status, and the top reasons by team.

## Worked example: Product team, Bengaluru GCC
A made-up team of 7 engineers. These are one manager's talks in October. Copy the shape, not the words.
- **Anjali M. · 6 Oct:** Wants to lead a small project. Felt passed over last time. Action: give her the next feature, by 1 Nov. Owner: manager. Done.
- **Rahul S. · 7 Oct:** Long commute from Whitefield. Action: ask for two set home days, by 20 Oct. Owner: HRBP. In progress.
- **Fatima K. · 9 Oct:** Unsure how the increment was set. Action: walk her through her pay band, by 23 Oct. Owner: manager. Done.
- **Karthik R. · 13 Oct:** Bored with support tickets. Action: one day a week on new code, from 1 Nov. Owner: manager. Not started.
- **Divya P. · 14 Oct:** Happy. Wants a mentor from another team. Action: ask L&D for a match, by 28 Oct. Owner: HRBP. In progress.
- **Sameer T. · 16 Oct:** Thought of leaving after he was told off in public. Action: manager to apologise and agree how to give feedback, by 18 Oct. Owner: manager. Done.

## How to run a stay talk
1. Book 30 minutes. Call it a stay talk, not a review.
2. Start warm. Say you want them to stay and grow here.
3. Ask the five questions, one at a time.
4. Listen. Do not explain or defend.
5. Agree one action, with an owner and a date.
6. Log it the same day.
7. Get back to them within two weeks.
