---
name: mimansa-bring-agents-into-a-team
description: Run Mimansa's Bring Agents Into a Team toolkit with an HR team. A six-step plan to start using AI agents in a team. Safely, fairly, and with a clear owner for every agent. Use when: a team wants to use an AI agent for real work; an agent is already running, but no one owns it; a manager asks, "What happens to my team's jobs?".
---

# Bring Agents Into a Team

A Mimansa toolkit, turned into a skill. Mimansa Research & Advisory, mimansa.work. Free to use and share.

Toolkit page: https://mimansa.work/toolkits/bring-agents-into-a-team.html

## What it helps with

**A plan for your first AI agent.** AI agents can now do real work. They book meetings, chase payments and update records. That saves time. It also raises new questions. Who checks the work? What can the agent promise? Who owns it when its maker leaves? This plan helps you answer them early. Before the agent starts, not after a mistake.

**Who it is for:** HRBPs, team managers, and the IT or ops lead who sets up the agent.

**Use it when:**
- A team wants to use an AI agent for real work.
- An agent is already running, but no one owns it.
- A manager asks, "What happens to my team's jobs?"

## How to work with the person
1. Ask who they are (HR head, HRBP, manager), the company's size and sector, and which step they are on. Start there.
2. Take the steps below in order. For each step, say who does it, what to do, and check the "done when" line before moving on.
3. Use the files in `tools/`. Spreadsheets: fill them with the person's own numbers and keep the formulas. One-page PDFs: use them as the script or checklist for the conversation, and draft their content in the same shape.
4. Write the way people talk: short sentences, plain words, no jargon. Indian context by default: April to March year, Indian labour law and practice.
5. Never make up a number. Ask for it, or mark it as a guess and say who should confirm it. For anything legal or statutory, ask them to check with payroll or an employment lawyer.
6. End each session with what was decided, who owns the next step, and by when.

## The steps

### Step 1: Map the tasks (Week 1)
Who: The manager leads this, with the HRBP.
- List 10 to 15 tasks for each role in the team.
- Mark each one: a person does it, the agent helps, or the agent does it.
- Circle the tasks that need judgment or face a customer.

Done when: Every task in the team has a mark.
Tools: Task Split Sheet

### Step 2: Set the agent's rules (Week 2)
Who: The manager and the IT lead write it. The HRBP checks it.
- Write down what the agent may do.
- Set limits on money and on promises.
- Say when it must stop and ask a person.

Done when: The agent's row in the Agent Register is complete and signed off by IT and infosec.
Tools: Agent Register

### Step 3: Name an owner (Week 2)
Who: The manager does this.
- Name one owner and one backup for each agent.
- Add the agent to the team's Agent Register.
- Agree who takes over if the owner leaves.

Done when: No agent is left without an owner.
Tools: Agent Register

### Step 4: Tell the team (Week 3)
Who: The manager leads this, with the HRBP.
- Explain what the agent does, and what it does not do.
- Make one rule clear: if you send the agent's work, you own it.
- Add the agent to new joiner induction.

Done when: Each person can say what the agent does and who to call.
Tools: Team Briefing Script

### Step 5: Check the work at 30 days (Week 7)
Who: The agent's owner and the manager do this together.
- Check 10 pieces of the agent's work.
- Count the mistakes and the fixes people had to make.
- Ask the team what got easier and what got harder.

Done when: You decide to keep, change or stop the agent.
Tools: 30-Day Check

### Step 6: Review roles and grades (Week 8)
Who: The HRBP leads this, with the rewards team.
- Look at what each role does now.
- Check if the grade and pay still fit the work.
- Keep some learning tasks for juniors, even if the agent could do them.

Done when: Each changed role has a new job summary and a grade decision.
Tools: Role Review Card

## The tools
- **Task Split Sheet** (`tools/Task Split Sheet.xlsx`): Each role's tasks, split between the person and the agent, with the hours that move.
- **Role Review Card** (`tools/Role Review Card.pdf`): What changes in a role, and whether the grade and pay still fit.
- **Agent Register** (`tools/Agent Register.xlsx`): Every agent: owner, systems and data, what it may and may never do, money limit, IT and infosec sign-off, review date.
- **Team Briefing Script** (`tools/Team Briefing Script.pdf`): A 10-minute talk for the manager before the agent goes live.
- **30-Day Check** (`tools/30-Day Check.xlsx`): A sample log of the agent's work, the error rate, fix time and complaints, and a keep, change or stop decision.

## Worked example: Payment Reminder Agent
Accounts receivable team, 9 people, Bengaluru. Copy the shape, not the words.
- **Owner · backup:** Priya R., AR lead · Arjun M., senior analyst
- **It may:** Send payment reminders to customers; Update the record after each reply; Book a call with the AR lead.
- **It must never:** Offer a discount; Change a due date; Promise a refund.
- **Money limit:** It cannot commit any money.
- **Flag doubt when:** A customer says the amount is wrong.
- **Stop and ask a person when:** The customer is upset, asks to change terms, or the bill is over Rs 5 lakh.
- **Review:** 90 days after go-live.

## How to fill in the Agent Register
1. Name the agent and its owner.
2. List the tasks it will do.
3. List what it must never do.
4. Set a money limit. Zero is a fine limit.
5. Say when it must flag doubt.
6. Say when it must hand over to a person.
7. Get the manager and HRBP to sign. Review it in 90 days.
