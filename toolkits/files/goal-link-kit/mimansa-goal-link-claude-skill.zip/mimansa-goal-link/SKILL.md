---
name: mimansa-goal-link
description: Run Mimansa's Goal Link toolkit with an HR team. Two tools to tie each goal to a number the business already tracks. Then split it into four quarters. Use when: goal setting starts for the new April to March year; leaders say goals do not match what the business needs; mid-year reviews find goals no one has looked at since April.
---

# Goal Link

A Mimansa toolkit, turned into a skill. Mimansa Research & Advisory, mimansa.work. Free to use and share.

Toolkit page: https://mimansa.work/toolkits/goal-link-kit.html

## What it helps with

**Goals the business cares about.** Many goals sound good. They link to nothing. No business review ever checks "Improve teamwork". This kit ties each goal to a number leaders already check. Sales looks at it in the pipeline review. Ops looks at it on the weekly call. Finance looks at it at month end. Then it splits each year goal into four quarter steps, from April to March. Remember Ganesha and Kartikeya. Make sure people race around the right thing.

**Who it is for:** HRBPs, performance teams and people managers who set goals each April.

**Use it when:**
- Goal setting starts for the new April to March year.
- Leaders say goals do not match what the business needs.
- Mid-year reviews find goals no one has looked at since April.

## How to work with the person
1. Ask who they are (HR head, HRBP, manager), the company's size and sector, and which step they are on. Start there.
2. Take the steps below in order. For each step, say who does it, what to do, and check the "done when" line before moving on.
3. Use the files in `tools/`. Spreadsheets: fill them with the person's own numbers and keep the formulas. One-page PDFs: use them as the script or checklist for the conversation, and draft their content in the same shape.
4. Write the way people talk: short sentences, plain words, no jargon. Indian context by default: April to March year, Indian labour law and practice.
5. Never make up a number. Ask for it, or mark it as a guess and say who should confirm it. For anything legal or statutory, ask them to check with payroll or an employment lawyer.
6. End each session with what was decided, who owns the next step, and by when.

## The steps

### Step 1: List the business numbers (Week 1)
Who: The HRBP does this, with the business head.
- Ask each leader which numbers they check every week or month.
- Note where each one is tracked and who owns it.
- Keep only numbers that already have an owner.

Done when: You have a short list of numbers the business tracks.
Tools: Goal Review Sheet

### Step 2: Match each goal to a number (Week 1)
Who: Each manager does this with their team. The HRBP checks it.
- Write each goal next to one business number.
- Add where the number is tracked and how often.
- Rewrite or drop any goal with no number.

Done when: Every goal has a business number and an owner.
Tools: Goal Review Sheet

### Step 3: Split it into quarters (Week 2)
Who: The goal owner does this with their manager.
- Write the full-year target for each goal.
- Set a milestone for each quarter, April to March.
- Make the June milestone small and sure.

Done when: Each goal has four quarter milestones.
Tools: Milestone Tracker

### Step 4: Check each goal (Week 3)
Who: The HRBP runs the check. Managers fix what fails.
- Run each goal through the Goal Review Sheet.
- Send back any goal that fails two or more checks.
- Sign off the rest with the business head.

Done when: Every goal passes the check and is signed off.
Tools: Goal Review Sheet

### Step 5: Review it each quarter (Every quarter)
Who: Managers do this with each person. The HRBP tracks the status.
- Check each milestone in the same week as the business review.
- Mark it on track, at risk or done.
- Change the next milestone if the business has changed.

Done when: Each goal has a fresh status every quarter.
Tools: Milestone Tracker

## The tools
- **Goal Review Sheet** (`tools/Goal Review Sheet.xlsx`): Every goal in one place: business number, owner, baseline, target, and an automatic keep, fix or drop.
- **Milestone Tracker** (`tools/Milestone Tracker.xlsx`): Quarter milestones and actuals for each goal, with an on-track, at-risk or off-track status.

## Worked example: Claims support team lead
Claims team, 40 people, at an insurance GCC in Hyderabad. This is an example. Copy the shape, not the words.
- **Role:** Team lead, claims support
- **Old goal:** Improve the customer experience.
- **Business number:** Share of claims solved on the first call
- **Where it is tracked:** Weekly ops call
- **Owner of the number:** Head of operations
- **New goal:** Raise first-call fixes from 62% to 75% by March 2027.
- **Q1 milestone:** 66% by June 2026
- **Q4 milestone:** 75% by March 2027

## How to turn a vague goal into a business goal
1. Write the goal as it is now.
2. Ask: which business number would this move?
3. Find where that number is tracked and who owns it.
4. Write today's number and the target for March.
5. Rewrite the goal with both numbers in it.
6. Split the gap into four quarter milestones.
