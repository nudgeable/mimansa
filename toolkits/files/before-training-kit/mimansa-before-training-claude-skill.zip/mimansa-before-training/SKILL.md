---
name: mimansa-before-training
description: Run Mimansa's Before Training toolkit with an HR team. Before a training, the manager and learner agree one or two actions. Then you check they happen. Use when: you are planning the training calendar for April to March; a manager wants to send people to a programme; a leader asks, "What did we get from that training?".
---

# Before Training

A Mimansa toolkit, turned into a skill. Mimansa Research & Advisory, mimansa.work. Free to use and share.

Toolkit page: https://mimansa.work/toolkits/before-training-kit.html

## What it helps with

**Agree the change before the class.** Most training ends on the last day. No one checks what people do after it. The fix starts before the class. The manager and the learner agree one or two things the person will do. They also agree by when, and who will see it. This kit helps you set that up in about 45 minutes for each team, in the week before the programme.

**Who it is for:** L&D leads, HRBPs, and the managers who pick people for training.

**Use it when:**
- You are planning the training calendar for April to March.
- A manager wants to send people to a programme.
- A leader asks, "What did we get from that training?"

## How to work with the person
1. Ask who they are (HR head, HRBP, manager), the company's size and sector, and which step they are on. Start there.
2. Take the steps below in order. For each step, say who does it, what to do, and check the "done when" line before moving on.
3. Use the files in `tools/`. Spreadsheets: fill them with the person's own numbers and keep the formulas. One-page PDFs: use them as the script or checklist for the conversation, and draft their content in the same shape.
4. Write the way people talk: short sentences, plain words, no jargon. Indian context by default: April to March year, Indian labour law and practice.
5. Never make up a number. Ask for it, or mark it as a guess and say who should confirm it. For anything legal or statutory, ask them to check with payroll or an employment lawyer.
6. End each session with what was decided, who owns the next step, and by when.

## The steps

### Step 1: Hold a 20-minute manager huddle (20 min)
Who: The L&D lead runs this with each learner's manager.
- Share the goal of the training in two lines.
- Ask what the manager wants to see the person do after it.
- Use the Cause Finder to see if training is the right fix.

Done when: The manager has named the gap and agrees training can help.
Tools: Cause Finder

### Step 2: Write the actions (15 min)
Who: The manager writes them, with help from the L&D lead.
- Write one or two actions with a verb, a number and how often.
- Set a date by when it should show.
- Name who will see it, and set the check-in dates.

Done when: Each action is something a person could see and count.
Tools: Contract Card

### Step 3: Filter the nominations (10 min)
Who: The manager and the L&D lead do this together.
- Run each name through the Nomination List.
- Keep people with a real gap and a chance to use the skill soon.
- Move the rest to a later batch or a different fix.

Done when: Every name on the list has passed the filter.
Tools: Nomination List

### Step 4: Sign the card on day one (Day 1)
Who: Each learner does this at the start of the training.
- Hand each learner the card their manager filled in.
- Ask them to read the actions and sign.
- Keep one copy for the manager and one for L&D.

Done when: Every learner has a signed card and knows the check-in dates.
Tools: Contract Card

## The tools
- **Cause Finder** (`tools/Cause Finder.pdf`): Skill, will, set-up, unclear goals or life outside work: find the cause before you pick the fix.
- **Nomination List** (`tools/Nomination List.xlsx`): Five tests for each name and an automatic send now, next batch or different fix.
- **Contract Card** (`tools/Contract Card.pdf`): What the learner will do differently, by when, and who will see it.

## Worked example: Field Sales Officer
Field sales team, 12 people, Pune. Names are made up. Copy the shape, not the words.
- **Participant:** Rahul K., sales officer
- **Programme:** Selling by asking, 2 days
- **Action 1:** Visit one more customer a day, five days a week.
- **Action 2:** Open each call by asking the customer's view. Every call.
- **By when:** Within 30 days of the training.
- **Who observes:** Meena S., area manager, on two joint visits a month.
- **Check-in dates:** Day 7, day 30 and day 60.

## How to write one behaviour you can see
1. Start with a verb you can see, like visit, ask or show.
2. Add a number. One more, two each, five a week.
3. Say how often. Each day, each call or each week.
4. Say by when it should start.
5. Name who will see it happen.
6. Read it aloud. If no one could see it, write it again.
