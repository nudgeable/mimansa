---
name: mimansa-potential-rating-health-check
description: Run Mimansa's Potential Rating Health Check toolkit with an HR team. In about an hour, check if your potential ratings are fair. And check if they tell you more than the performance rating does. Use when: before the yearly talent review; when your top potential list looks too much like one group; when a leader asks, "What does potential mean here?".
---

# Potential Rating Health Check

A Mimansa toolkit, turned into a skill. Mimansa Research & Advisory, mimansa.work. Free to use and share.

Toolkit page: https://mimansa.work/toolkits/potential-rating-health-check.html

## What it helps with

**A quick check on one score.** Most firms rate potential each year. Few can say what it means. So the score can hide bias. It can also just copy the performance score. This kit helps you test both. You need one export and about an hour.

**Who it is for:** HRBPs, talent leads and CHROs. Bring one person who can work with Excel.

**Use it when:**
- Before the yearly talent review.
- When your top potential list looks too much like one group.
- When a leader asks, "What does potential mean here?"

## How to work with the person
1. Ask who they are (HR head, HRBP, manager), the company's size and sector, and which step they are on. Start there.
2. Take the steps below in order. For each step, say who does it, what to do, and check the "done when" line before moving on.
3. Use the files in `tools/`. Spreadsheets: fill them with the person's own numbers and keep the formulas. One-page PDFs: use them as the script or checklist for the conversation, and draft their content in the same shape.
4. Write the way people talk: short sentences, plain words, no jargon. Indian context by default: April to March year, Indian labour law and practice.
5. Never make up a number. Ask for it, or mark it as a guess and say who should confirm it. For anything legal or statutory, ask them to check with payroll or an employment lawyer.
6. End each session with what was decided, who owns the next step, and by when.

## The steps

### Step 1: Export the ratings (10 min)
Who: The HRBP or HR analyst does this.
- Pull last cycle's ratings from your HR system.
- Keep five things: ID, gender, both scores and manager.
- Remove names before you share the file.

Done when: Every rated person is one row in the Potential Ratings Audit.
Tools: Potential Ratings Audit

### Step 2: Split by gender (10 min)
Who: The HR analyst does this.
- Fill the gender column from the dropdown.
- The cells at the bottom find the mean for each group.
- Note the share of women and men with the top potential score.

Done when: You can see both groups side by side.
Tools: Potential Ratings Audit

### Step 3: Compare the scores (15 min)
Who: The HRBP leads this, with the talent lead.
- Look at the gap in performance, then the gap in potential.
- Ask why a group does better work but gets a lower potential score.
- See which managers gave big gaps. Did a new boss change a score?

Done when: You can name the gap and the managers behind it.
Tools: Potential Ratings Audit

### Step 4: Check what happened next (15 min)
Who: The talent lead does this.
- Find people rated high potential two or three years ago.
- Check who was promoted, who did well and who left.
- Use the Proxy Test to see if potential just repeats performance.

Done when: You know if the score has guessed the future well.
Tools: Proxy Test

### Step 5: Take it to the talent review (10 min)
Who: The HRBP presents. The CHRO or business head decides.
- Show the gap on one slide, with the managers' names removed.
- Ask the panel to define potential in one line.
- Agree what changes this cycle, and who owns it.

Done when: The panel has agreed one change to how potential is rated.
Tools: Proxy Test

## The tools
- **Proxy Test** (`tools/Proxy Test.pdf`): Seven questions that show whether potential scores measure something else.
- **Potential Ratings Audit** (`tools/Potential Ratings Audit.xlsx`): Paste your 9-box export. See gaps by gender, location and tenure, with small-group warnings, and how ratings move with a new manager.

## Worked example: Sales team, 2025 to 26 cycle
A made-up sales team of 140 people in Pune and Chennai. Copy the shape, not the numbers.
- **People rated:** 140. Women 52, men 88.
- **Average performance (1 to 5):** Women 3.6. Men 3.4.
- **Average potential (1 to 3):** Women 1.8. Men 2.1.
- **Top potential score (3):** Women 10%. Men 22%.
- **Gap:** Women rate higher on work, but lower on potential.
- **Managers with the biggest gap:** Two regional heads. Both new this year.
- **Next step:** Take it to the talent review in May. Ask each manager for evidence.

## How to check potential ratings for bias in an hour
1. Export last cycle's ratings. Keep ID, gender, both scores and the manager.
2. Paste them into the Potential Ratings Audit.
3. Read the gaps. Is one group higher on work but lower on potential?
4. Sort by manager. Look for the biggest gaps.
5. Check the Potential Ratings Audit. Did scores move when the manager changed?
6. Run the Proxy Test with two or three leaders.
7. Take one slide to the talent review. Agree one change.
