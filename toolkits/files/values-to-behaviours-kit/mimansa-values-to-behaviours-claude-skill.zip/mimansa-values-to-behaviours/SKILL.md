---
name: mimansa-values-to-behaviours
description: Run Mimansa's Values to Behaviours toolkit with an HR team. Three tools to turn each value into three things people can see. Staff can act on them. Managers can judge them. Use when: you have new values and need them to stick; staff roll their eyes when values come up; reviews ask about values, but no one knows how to rate them.
---

# Values to Behaviours

A Mimansa toolkit, turned into a skill. Mimansa Research & Advisory, mimansa.work. Free to use and share.

Toolkit page: https://mimansa.work/toolkits/values-to-behaviours-kit.html

## What it helps with

**Values you can see.** Most firms have values on the wall. Few staff can say what they mean on a busy day. A value like "Customer first" is too big to act on. People need to know what to do at the counter, on the call, or in the meeting. This kit turns each value into three clear actions and two things to avoid. Each one comes from a real story in your firm.

**Who it is for:** HR heads, HRBPs, culture and L&D teams, and the managers who live the values each day.

**Use it when:**
- You have new values and need them to stick.
- Staff roll their eyes when values come up.
- Reviews ask about values, but no one knows how to rate them.

## How to work with the person
1. Ask who they are (HR head, HRBP, manager), the company's size and sector, and which step they are on. Start there.
2. Take the steps below in order. For each step, say who does it, what to do, and check the "done when" line before moving on.
3. Use the files in `tools/`. Spreadsheets: fill them with the person's own numbers and keep the formulas. One-page PDFs: use them as the script or checklist for the conversation, and draft their content in the same shape.
4. Write the way people talk: short sentences, plain words, no jargon. Indian context by default: April to March year, Indian labour law and practice.
5. Never make up a number. Ask for it, or mark it as a guess and say who should confirm it. For anything legal or statutory, ask them to check with payroll or an employment lawyer.
6. End each session with what was decided, who owns the next step, and by when.

## The steps

### Step 1: Collect real stories (Week 1)
Who: The HRBP leads this, with two or three managers.
- Ask staff for a time someone lived the value.
- Write down what the person did, step by step.
- Get at least five stories for each value.

Done when: Each value has five real stories.
Tools: Behaviour Canvas

### Step 2: Write the do and don't (Week 2)
Who: The HRBP writes it. The value owner checks it.
- Find what the people in the stories did again and again.
- Write three do lines and two don't lines.
- Use the words staff use at work.

Done when: Each value has a Behaviour Canvas with 3 do and 2 don't lines.
Tools: Behaviour Canvas

### Step 3: Ask what it means for managers (Week 3)
Who: Each manager fills this in. The HRBP runs a short session.
- Pick two or three things the manager will do each week.
- Say how the team will notice them.
- Write what the manager will do when they fall short.

Done when: Every manager has a filled card for each value.
Tools: Manager Values Commitments

### Step 4: Test with 5 staff (Week 4)
Who: The HRBP does this, with five staff from different teams.
- Read each line to five staff.
- Ask: could you do this tomorrow? Could your manager see it?
- Fix or drop any line that two people find unclear.

Done when: Five staff agree each line is clear.
Tools: Behaviour Canvas

### Step 5: Share it and use it in reviews (Ongoing)
Who: The HR head owns this. Managers use it every day.
- Put the Values One-Pager on walls and in the joining kit.
- Add the do lines to the review form.
- Ask managers to share one story a month.

Done when: Every review asks about the do lines.
Tools: Values One-Pager

## The tools
- **Behaviour Canvas** (`tools/Behaviour Canvas.pdf`): Do and don't lines for one value that a manager can see.
- **Values One-Pager** (`tools/Values One-Pager.pdf`): Every value's do and don't lines on one page.
- **Manager Values Commitments** (`tools/Manager Values Commitments.pdf`): What each manager will do for a value, and a check with the team after 3 months.

## Worked example: Customer first
A bike service centre chain with 14 outlets in Mumbai. This is an example. Copy the shape, not the words.
- **Value:** Customer first
- **Do 1:** Give an accurate estimate before we start.
- **Do 2:** Call the customer before any extra repair.
- **Do 3:** Explain a mistake honestly, and say how we will fix it.
- **Don't 1:** Add a part or a repair without asking.
- **Don't 2:** Blame the rider for a fault we caused.
- **Real story:** At the Andheri outlet, Ravi found a worn chain. He called the owner before he fixed it. She said yes. Next month she brought her brother's bike too.
- **Small touch:** Offer tea while the customer waits.

## How to turn a value into 3 behaviours
1. Pick one value.
2. Ask staff for a time someone lived it.
3. Find what that person did. Write it as an action.
4. Write three do lines and two don't lines.
5. Check that a manager could see each one.
6. Test the lines with five staff, then fix them.
