---
name: mimansa-retrain-managers-in-direct-feedback
description: Run Mimansa's Retrain Managers in Direct Feedback toolkit with an HR team. A six-week plan for managers. They learn to give clear feedback on time. They also learn to welcome questions from young teams. Use when: young joiners say they never hear how they are doing; a manager says, "They argue all the time."; your staff survey scores low on feedback.
---

# Retrain Managers in Direct Feedback

A Mimansa toolkit, turned into a skill. Mimansa Research & Advisory, mimansa.work. Free to use and share.

Toolkit page: https://mimansa.work/toolkits/retrain-managers-in-direct-feedback.html

## What it helps with

**A practice plan for managers.** Young people at work often ask why. Some managers hear that as rude. Then they go quiet, and feedback stops. This plan builds a simple habit. Say what you saw, why it matters and what comes next. Then ask the team for feedback too. Like young Nachiketa in the old story, many want the real answer. Give it to them, kindly and clearly.

**Who it is for:** People managers, team leads, HRBPs and L&D partners.

**Use it when:**
- Young joiners say they never hear how they are doing.
- A manager says, "They argue all the time."
- Your staff survey scores low on feedback.

## How to work with the person
1. Ask who they are (HR head, HRBP, manager), the company's size and sector, and which step they are on. Start there.
2. Take the steps below in order. For each step, say who does it, what to do, and check the "done when" line before moving on.
3. Use the files in `tools/`. Spreadsheets: fill them with the person's own numbers and keep the formulas. One-page PDFs: use them as the script or checklist for the conversation, and draft their content in the same shape.
4. Write the way people talk: short sentences, plain words, no jargon. Indian context by default: April to March year, Indian labour law and practice.
5. Never make up a number. Ask for it, or mark it as a guess and say who should confirm it. For anything legal or statutory, ask them to check with payroll or an employment lawyer.
6. End each session with what was decided, who owns the next step, and by when.

## The steps

### Step 1: Take a baseline pulse (Week 1)
Who: The HRBP runs this for each manager's team.
- Send the Team Pulse Survey to each team.
- Keep it anonymous, with five questions only.
- Show each manager only their own team's scores.

Done when: Each manager has a starting score.
Tools: Team Pulse Survey

### Step 2: Practise SBI in pairs (Week 2)
Who: L&D runs a 60-minute session. Managers work in pairs.
- Learn the three parts of SBI: what, how, so what.
- Practise three real cases each, in pairs.
- Swap roles and give each other one tip.

Done when: Each manager has said three SBI lines out loud.
Tools: SBI Script Card

### Step 3: Hold weekly 15-minute check-ins (Week 3)
Who: Each manager does this with each person in the team.
- Book 15 minutes with each person, every week.
- Give one SBI line on something real from the week.
- Agree one next step and log it in the tracker.

Done when: Every person has had a check-in this week.
Tools: Feedback Log

### Step 4: Ask for feedback first (Week 4)
Who: Each manager does this in a team meeting.
- Ask the team one question about how you lead.
- Thank them, and do not defend.
- Act on one point and report back next week.

Done when: The team has seen the manager act on their feedback.
Tools: Upward Feedback Card

### Step 5: Observe a peer (Week 5)
Who: Managers pair up. The HRBP sets the pairs.
- Sit in on one check-in, with the team member's consent.
- Note one thing that worked and one thing to try.
- Share it with your peer within a day.

Done when: Each manager has been observed once.
Tools: Peer Observation Sheet

### Step 6: Pulse again and recognise (Week 6)
Who: The HRBP runs the pulse. Senior leaders do the thanks.
- Send the same Team Pulse Survey again.
- Compare each team's score with week 1.
- Thank managers who improved, by name, in a leaders' meeting.

Done when: Scores are shared and progress is thanked.
Tools: Team Pulse Survey

## The tools
- **Team Pulse Survey** (`tools/Team Pulse Survey.xlsx`): Five questions to set up as a Google or Microsoft form, and a sheet that compares week 1 with week 6 for each manager.
- **SBI Script Card** (`tools/SBI Script Card.pdf`): Situation, behaviour, impact, ask, next step. One card per piece of feedback.
- **Peer Observation Sheet** (`tools/Peer Observation Sheet.pdf`): What a peer watches for in a feedback talk, and the notes to share.
- **Upward Feedback Card** (`tools/Upward Feedback Card.pdf`): One question for your team about you. Then thank, act and report back.
- **Feedback Log** (`tools/Feedback Log.xlsx`): Every feedback talk in one log: what you saw, the impact, their view, the next step and whether it happened.

## Worked example: Feedback to a Junior Analyst
Finance team, 8 people, a GCC in Gurugram. Names are made up. Copy the shape, not the words.
- **Situation:** In Tuesday's client call with the Mumbai team.
- **Behaviour:** Kavya, you shared the cash report two hours after the deadline.
- **Impact:** The client waited, and I had to say sorry for the delay.
- **Ask:** What got in the way?
- **Listen:** She says the data came late from another team.
- **Next step:** Kavya flags late data by 3 pm. I will speak to the other team lead.
- **Check:** We look at it again in Friday's check-in.

## How to give hard feedback in 5 minutes
1. Pick one thing. Only one.
2. Say when and where it happened.
3. Say what the person did. Stick to what you saw.
4. Say what it caused.
5. Ask what got in the way, and listen.
6. Agree one next step and a date.
7. Write it in the tracker the same day.
