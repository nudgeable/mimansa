---
name: mimansa-clear-update
description: Run Mimansa's Clear Update toolkit with an HR team. A short weekly update people can trust. It is 300 words, with a source beside every number and one clear ask. Use when: your update gets a bit longer each week; leaders reply, "So what do you need from us?"; a number in a report turned out to be wrong.
---

# Clear Update

A Mimansa toolkit, turned into a skill. Mimansa Research & Advisory, mimansa.work. Free to use and share.

Toolkit page: https://mimansa.work/toolkits/clear-update-kit.html

## What it helps with

**An update people can trust.** AI can write a long update in seconds. It often looks good and says little. Someone else then has to fix it. This kit keeps the weekly update short and true. It says what changed, what needs care and what you need. Each number has its source next to it. The update ends with one clear ask.

**Who it is for:** Team leads, managers, HRBPs, and anyone who writes weekly updates.

**Use it when:**
- Your update gets a bit longer each week.
- Leaders reply, "So what do you need from us?"
- A number in a report turned out to be wrong.

## How to work with the person
1. Ask who they are (HR head, HRBP, manager), the company's size and sector, and which step they are on. Start there.
2. Take the steps below in order. For each step, say who does it, what to do, and check the "done when" line before moving on.
3. Use the files in `tools/`. Spreadsheets: fill them with the person's own numbers and keep the formulas. One-page PDFs: use them as the script or checklist for the conversation, and draft their content in the same shape.
4. Write the way people talk: short sentences, plain words, no jargon. Indian context by default: April to March year, Indian labour law and practice.
5. Never make up a number. Ask for it, or mark it as a guess and say who should confirm it. For anything legal or statutory, ask them to check with payroll or an employment lawyer.
6. End each session with what was decided, who owns the next step, and by when.

## The steps

### Step 1: Write the three parts (15 min)
Who: The person who sends the update does this.
- Write what changed this week.
- Write what needs care, and why.
- Write what decision you need, and from whom.

Done when: The update has three parts and stays under 300 words.
Tools: 300-Word Update Template

### Step 2: Add the sources (5 min)
Who: The writer does this. A teammate can check it.
- Put the source in brackets beside each number.
- Open each source and check the number.
- Remove any number you cannot trace.

Done when: Every number has a source beside it.
Tools: 300-Word Update Template

### Step 3: Write the recommendation (5 min)
Who: The writer does this.
- Say what you recommend in one line.
- Say who should decide.
- Say by when.

Done when: A busy reader knows what you want from one line.
Tools: 300-Word Update Template

### Step 4: Do the send-check (5 min)
Who: The writer does this just before sending.
- Read the update aloud once.
- Ask yourself: can I explain every number with no notes?
- Cut any line you cannot explain.

Done when: You can explain every number and every line.
Tools: 300-Word Update Template

## The tools
- **300-Word Update Template** (`tools/300-Word Update Template.pdf`): What changed, what needs care, the decision, a clear recommendation line, a source beside each number and a send-check.

## Worked example: Weekly Update to US Leaders
Payroll team in a Bengaluru GCC, 14 people. The numbers are made up. Copy the shape, not the words.
- **Vague: what changed:** "We saw strong progress across key payroll workstreams."
- **Clear: what changed:** Error tickets fell from 42 to 29 this week (ticket tool, 18 Oct).
- **Vague: needs care:** "Some risks may impact timelines going forward."
- **Clear: needs care:** Two of five payroll staff are on leave next week (leave tracker).
- **Vague: decision:** "We look forward to alignment on next steps."
- **Clear: recommendation:** Approve one temp for two weeks. The US payroll head decides by Wednesday.
- **Length:** Clear version: 180 words.

## How to rewrite a vague AI report
1. Read the draft and underline every number.
2. Find the source for each one. Delete what you cannot find.
3. Cut empty words like key, robust and going forward.
4. Write one line each: what changed, what needs care, what you need.
5. Add one ask: what, who and by when.
6. Read it aloud. Cut it to 300 words or less.
