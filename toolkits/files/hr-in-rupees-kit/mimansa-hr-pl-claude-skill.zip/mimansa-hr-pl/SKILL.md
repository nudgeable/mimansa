---
name: mimansa-hr-pl
description: Run Mimansa's HR P&L toolkit with an HR team. One workbook to build the people side of your P&L: what people cost, what leavers and open roles cost, the ratios a CFO reads, and a one-page board summary. Use when: the annual plan or budget; the board asks what attrition really costs; you need money to fix a people problem.
---

# HR P&L

A Mimansa toolkit, turned into a skill. Mimansa Research & Advisory, mimansa.work. Free to use and share.

Toolkit page: https://mimansa.work/toolkits/hr-in-rupees-kit.html

## What it helps with

**Read HR the way the CFO does.** Finance reads the business through its P&L. This kit builds the people side of it, from the same books. One workbook brings together people cost line by line, the cost of attrition by role family, the cost of open roles, and ratios like revenue per FTE and human capital ROI. It ends in a one-page board summary with a three-year trend and one clear ask.

**Who it is for:** CHROs, HR heads and HRBPs who present to the CEO, the CFO or the board, working with their finance partner.

**Use it when:**
- The annual plan or budget.
- The board asks what attrition really costs.
- You need money to fix a people problem.

## How to work with the person
1. Ask who they are (HR head, HRBP, manager), the company's size and sector, and which step they are on. Start there.
2. Take the steps below in order. For each step, say who does it, what to do, and check the "done when" line before moving on.
3. Use the files in `tools/`. Spreadsheets: fill them with the person's own numbers and keep the formulas. One-page PDFs: use them as the script or checklist for the conversation, and draft their content in the same shape.
4. Write the way people talk: short sentences, plain words, no jargon. Indian context by default: April to March year, Indian labour law and practice.
5. Never make up a number. Ask for it, or mark it as a guess and say who should confirm it. For anything legal or statutory, ask them to check with payroll or an employment lawyer.
6. End each session with what was decided, who owns the next step, and by when.

## The steps

### Step 1: Gather the numbers (2 hours)
Who: The HRBP does this with the finance partner.
- Get three years of revenue, operating cost and EBITDA.
- Get the payroll register, the trial balance and the headcount report.
- Fill tabs 1 and 2. Check the statutory lines with payroll.

Done when: People cost matches the books, line by line.
Tools: HR P&L Workbook

### Step 2: Price leavers and open roles (2 hours)
Who: The HRBP does this with each business head.
- Fill one row per role family on tab 3.
- Agree days to fill, ramp-up and the value of the role with the business head.
- Cost each open role on tab 4 with the method that fits it.

Done when: Every guess has an owner outside HR.
Tools: HR P&L Workbook

### Step 3: Read the ratios and the trend (1 hour)
Who: The HR head does this with the CFO's team.
- Read tabs 5 and 6 together.
- Pick the three numbers that matter most for your business.
- Check each one with finance before anyone else sees it.

Done when: The CFO agrees with every number you will show.
Tools: HR P&L Workbook

### Step 4: Present the board summary (1 hour)
Who: The HR head presents. The CFO backs the numbers.
- Fill the ask on tab 7: the cost, the saving and the decision.
- Say what it cost first, then the rate.
- End with one decision you need that day.

Done when: The board makes a clear yes or no decision.
Tools: HR P&L Workbook

## The tools
- **HR P&L Workbook** (`tools/HR P&L Workbook.xlsx`): People cost line by line, the cost of attrition and open roles, CFO ratios, a three-year trend and a one-page board summary. Worked example included.

## Worked example: A 1,200-person services company
FY 2025-26. All names and figures are made up. Copy the shape, not the numbers.
- **Company:** IT and business services, 1,200 employees
- **Revenue and EBITDA:** ₹480 crore and ₹72 crore (15%)
- **People cost:** ₹207.6 crore, 43% of revenue
- **Revenue per FTE:** ₹35.6 lakh, up from ₹35.0 lakh
- **Human capital ROI:** 1.35x, up from 1.31x
- **Attrition:** 21%, 252 leavers
- **Cost of attrition:** ₹23.1 crore, 32% of EBITDA
- **Costliest leaver:** A senior engineer: ₹16.9 lakh, about 8 months of pay
- **The ask:** ₹1.2 crore to keep senior engineers. It saves about ₹2.5 crore a year and pays back in 6 months.

## How to show the business value of an HR number
1. Start from a number the board already tracks: revenue, cost or profit.
2. Find the people number that moves it, such as attrition in a key role.
3. Price it with methods finance accepts. Write each guess down, with who agreed it.
4. Show it as a share of profit, and next to last year.
5. Put the ask next to the saving, with a payback date.
6. Check every number with the CFO before the meeting.
