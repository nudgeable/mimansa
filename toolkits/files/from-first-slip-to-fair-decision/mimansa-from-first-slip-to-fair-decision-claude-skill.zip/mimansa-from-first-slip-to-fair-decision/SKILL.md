---
name: mimansa-from-first-slip-to-fair-decision
description: Run Mimansa's From First Slip to Fair Decision toolkit with an HR team. Six plays for the first sign of weak work. Act early, find the real cause, give real help. Only then decide. Use when: good work has slipped for a few weeks; a manager says, "I think we need a PIP."; someone is on a PIP, and no one knows why it started.
---

# From First Slip to Fair Decision

A Mimansa toolkit, turned into a skill. Mimansa Research & Advisory, mimansa.work. Free to use and share.

Toolkit page: https://mimansa.work/toolkits/from-first-slip-to-fair-decision.html

## What it helps with

**Help first, decide later.** Most PIPs start too late. By then the manager has made up their mind. This plan starts at the first slip. You talk early, find the cause and give real help for 30 days. Then you decide, with a clear record. Legal steps in India depend on the person's role and the new labour codes. So check with your legal team.

**Who it is for:** People managers and HRBPs. The team lead or skip manager may join at play 5.

**Use it when:**
- Good work has slipped for a few weeks.
- A manager says, "I think we need a PIP."
- Someone is on a PIP, and no one knows why it started.

## How to work with the person
1. Ask who they are (HR head, HRBP, manager), the company's size and sector, and which step they are on. Start there.
2. Take the steps below in order. For each step, say who does it, what to do, and check the "done when" line before moving on.
3. Use the files in `tools/`. Spreadsheets: fill them with the person's own numbers and keep the formulas. One-page PDFs: use them as the script or checklist for the conversation, and draft their content in the same shape.
4. Write the way people talk: short sentences, plain words, no jargon. Indian context by default: April to March year, Indian labour law and practice.
5. Never make up a number. Ask for it, or mark it as a guess and say who should confirm it. For anything legal or statutory, ask them to check with payroll or an employment lawyer.
6. End each session with what was decided, who owns the next step, and by when.

## The steps

### Step 1: Spot the pattern (Week 1)
Who: The manager does this.
- Note three or more slips over two to three weeks.
- Write facts: dates, tasks and what was missed.
- Check if the work, team or goals changed lately.

Done when: You have a short list of facts, not a feeling.
Tools: First Signs Checklist

### Step 2: Give clear feedback (Week 1)
Who: The manager does this, in private.
- Meet within a week of seeing the pattern.
- Say what you saw and why it matters. Then listen.
- Agree what good looks like, and when you will check again.

Done when: The talk is in the Feedback Log, with the person's view.
Tools: Feedback Log

### Step 3: Find the cause (Week 2)
Who: The manager and the HRBP do this together.
- Look at five causes: skill, will, unclear goals, how work is set up, and life outside work.
- Ask the person what is getting in the way.
- Pick the one or two causes that fit the facts.

Done when: You agree on the main cause, and the person has been heard.
Tools: Cause Finder

### Step 4: Run a 30-day support sprint (Weeks 3 to 6)
Who: The manager runs it. The HRBP checks in at the midpoint.
- Set two or three clear goals for the month.
- Give real help: training, a buddy, time or fewer tasks. Note the cost in ₹.
- Meet once a week. Write down what moved.

Done when: Four check-ins are done, and the help was actually given.
Tools: 30-Day Support Plan

### Step 5: Decide, fairly (Week 7)
Who: The manager and the HRBP decide. The skip manager signs off.
- Look at the goals, the help given and the check-in notes.
- Choose one: improved, a formal PIP, a move to another role, or a respectful exit.
- Tell the person in a calm, private talk. Put it in writing.

Done when: The decision is made, told and written down.
Tools: Case Timeline

### Step 6: Close it and log it (Week 8)
Who: The HRBP does this.
- Fill in the Case Timeline with all the dates.
- Check how long each step took.
- Note one thing to do sooner next time.

Done when: The case is closed, with a full and fair record.
Tools: Case Timeline

## The tools
- **First Signs Checklist** (`tools/First Signs Checklist.pdf`): The facts to write down before you talk to anyone.
- **Cause Finder** (`tools/Cause Finder.pdf`): Skill, will, set-up, unclear goals or life outside work: find the cause before you pick the fix.
- **Feedback Log** (`tools/Feedback Log.xlsx`): Every feedback talk in one log: what you saw, the impact, their view, the next step and whether it happened.
- **Case Timeline** (`tools/Case Timeline.xlsx`): Days from first slip to feedback, HRBP and plan, case by case.
- **30-Day Support Plan** (`tools/30-Day Support Plan.pdf`): Goals, support promised and given, weekly check-ins, the employee's acknowledgement and the checks before any separation step.

## Worked example: Customer support lead, Hyderabad
A made-up case. Ravi K. led a shift of 8 well for two years. Then his team's tickets began to slip. Copy the shape, not the words.
- **Cause found:** Unclear goals. A new tool came in, and no one set new targets for it.
- **Goal 1:** Close 90% of tickets within 24 hours by day 30.
- **Goal 2:** Run a 10-minute team huddle each morning.
- **Help given:** Two days of tool training. A buddy from the Pune team. One less report each week.
- **Cost:** ₹18,000 for training. No other cost.
- **Check-ins:** Every Friday at 4 pm. Days 7, 14, 21 and 28.
- **Outcome:** Improved. 92% of tickets closed on time by day 28.

## How to have the first hard talk
1. Book 30 minutes in a quiet room. Not on a Friday evening.
2. Start with care. Say you want to help.
3. Share two or three facts. Dates and tasks, not labels.
4. Ask, "How do you see it?" Then listen without cutting in.
5. Agree what good looks like, and one next step.
6. Set a date to check in again.
7. Write it in the Feedback Log the same day.
