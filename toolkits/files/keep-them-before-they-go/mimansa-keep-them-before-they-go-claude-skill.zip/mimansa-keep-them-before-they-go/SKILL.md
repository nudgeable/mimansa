---
name: mimansa-keep-them-before-they-go
description: Run Mimansa's Keep Them Before They Go toolkit with an HR team. A six-play plan to keep good people. Spot risk early, talk often, and act fast when something changes. Use when: good people are leaving, and the exit reasons don't add up; a key person has had a shock, like a missed promotion; you want a simple monthly habit to keep people.
---

# Keep Them Before They Go

A Mimansa toolkit, turned into a skill. Mimansa Research & Advisory, mimansa.work. Free to use and share.

Toolkit page: https://mimansa.work/toolkits/keep-them-before-they-go.html

## What it helps with

**Act while they are still here.** People rarely quit in one day. Small shocks build up. A missed promotion. A new boss. A friend who left. A call from a recruiter. By the exit talk, it is too late. People give a polite reason, like better pay or a personal reason. The real one stays unsaid. Many find it hard to speak up to a boss. This plan helps you act early. Spot the risk. Hold stay talks. Respond to shocks. Bring in a counsellor or a senior leader in time.

**Who it is for:** HRBPs, people managers, and the senior leaders who sponsor key people.

**Use it when:**
- Good people are leaving, and the exit reasons don't add up.
- A key person has had a shock, like a missed promotion.
- You want a simple monthly habit to keep people.

## How to work with the person
1. Ask who they are (HR head, HRBP, manager), the company's size and sector, and which step they are on. Start there.
2. Take the steps below in order. For each step, say who does it, what to do, and check the "done when" line before moving on.
3. Use the files in `tools/`. Spreadsheets: fill them with the person's own numbers and keep the formulas. One-page PDFs: use them as the script or checklist for the conversation, and draft their content in the same shape.
4. Write the way people talk: short sentences, plain words, no jargon. Indian context by default: April to March year, Indian labour law and practice.
5. Never make up a number. Ask for it, or mark it as a guess and say who should confirm it. For anything legal or statutory, ask them to check with payroll or an employment lawyer.
6. End each session with what was decided, who owns the next step, and by when.

## The steps

### Step 1: Know who matters and who is at risk (Week 1)
Who: The HRBP and the manager do this together.
- List the key people in the team.
- Score six simple risk signals for each person.
- Score them again every month.

Done when: Each key person has a risk level and an owner.
Tools: Retention Risk Radar

### Step 2: Hold stay talks (Weeks 2 to 4)
Who: The manager does this, one person at a time.
- Book 30 minutes with each person.
- Ask the five stay questions.
- Agree one action with each person.

Done when: Each person has had a stay talk and has one action.
Tools: Five Stay Questions

### Step 3: Respond to shocks within 7 days (From week 2)
Who: The manager does this. The HRBP keeps watch.
- Watch for shocks, big or small.
- Hold a short check-in within 7 days.
- Note the shock on the risk list.

Done when: Each shock got a check-in within a week.
Tools: Shock Response Card

### Step 4: Offer a counsellor early (When needed)
Who: The HRBP does this, with care.
- Spot signs of strain, stress or a hard life event.
- Offer a counsellor. Make it clear it is a free choice.
- Keep it private. Do not ask what was said.

Done when: The person knows help is there and how to reach it.
Tools: Counsellor Referral Guide

### Step 5: Bring a senior leader in early (Weeks 4 to 6)
Who: A senior leader does this, for key people at risk.
- Hold a skip-level talk.
- Name a sponsor for the person.
- Agree one growth step people can see.

Done when: Each key person at risk has met a senior leader.
Tools: Skip-Level Talk Guide

### Step 6: Review retention every month (Week 8, then monthly)
Who: The HRBP runs it, with the team's leaders.
- Hold a 30-minute huddle each month.
- Look at the risk list and the open actions.
- Talk about who left and the real reason.

Done when: Every action has an owner and a date.
Tools: Monthly Retention Huddle

## The tools
- **Retention Risk Radar** (`tools/Retention Risk Radar.xlsx`): For HRBPs only. Risk signals and impact for each person, a risk × impact grid, and who to act on now.
- **Five Stay Questions** (`tools/Five Stay Questions.pdf`): The questions to ask, in order, with space for their words and one agreed action.
- **Shock Response Card** (`tools/Shock Response Card.pdf`): What to say within 7 days of a shock, and what to agree.
- **Skip-Level Talk Guide** (`tools/Skip-Level Talk Guide.pdf`): A 30-minute talk for senior leaders with key people at risk.
- **Monthly Retention Huddle** (`tools/Monthly Retention Huddle.pdf`): A 30-minute monthly agenda, run from the Retention Risk Radar.
- **Counsellor Referral Guide** (`tools/Counsellor Referral Guide.pdf`): How to notice, offer and point to the EAP or Tele-MANAS. Managers refer; counsellors help.

## Worked example: One row from a product team
Product team, 12 people, Pune. Names are made up. Copy the shape, not the words.
- **Person:** Example: Ravi K., senior developer. Key person: Yes.
- **What happened:** Missed promotion in April. New manager in May. Engagement dip in the pulse survey.
- **Signals scored 1:** Shock. New boss. Missed promotion. Engagement dip.
- **Risk score:** 4 out of 6
- **Risk level:** High
- **Action:** Stay talk this week. Skip-level talk with the Head of Product by 20 June.
- **Owner:** Neha S., manager. HRBP checks in two weeks.

## How to run a stay talk
1. Book 30 minutes. Pick a calm time.
2. Say why. This is not a review.
3. Ask the five stay questions.
4. Listen. Do not defend or explain.
5. Agree one action together.
6. Follow up in two weeks.
